﻿function host() {
    return "http://sugarcube.azurewebsites.net";
    //return "http://localhost:1709";
}